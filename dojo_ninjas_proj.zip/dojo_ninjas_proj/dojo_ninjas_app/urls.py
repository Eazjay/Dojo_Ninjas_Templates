from django.urls import path
from . import views

urlpatterns = [
    path('', views.index),
    path('create_dojo', views.processDojoForm),
    path('create_ninja', views.processNinjaForm),
]